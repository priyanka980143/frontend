import Changenumber from "./Changenumber";
// import Textchange from "./Textchange";
import Textchange from "./Textchange";
import {combineReducers} from "redux";
// import Bgchange from "./Bgchange";

const rootreducer = combineReducers({
    Changenumber ,Textchange 
}
)
export default rootreducer