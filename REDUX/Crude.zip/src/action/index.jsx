export const Incnumber =()=>{
    return{
        type : "INCREMENT"
    }
}
export const Decnumber =()=>{
    return{
        type : "DECREMENT"
    }
}
export const Textchange =()=>{
    return{
        type : "TEXTCHANGE"
    }
}
export const Bgchange =()=>{
    return{
        type : "BGCHANGE"
    }
}